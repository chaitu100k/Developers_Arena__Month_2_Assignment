
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("Sales_Dataset.csv")

# Summary Statistics
print("Summary Statistics:\n", df.describe())

# Correlation Matrix
corr = df.corr(numeric_only=True)
print("\nCorrelation Matrix:\n", corr)

# Plot Correlation Heatmap
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()
