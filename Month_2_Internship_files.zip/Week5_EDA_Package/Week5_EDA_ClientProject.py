
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("Sales_Dataset.csv")

# Basic Info
print(df.info())

# Summary Statistics
print(df.describe())

# Missing values check
print("Missing Values:\n", df.isnull().sum())

# Sales distribution
plt.figure(figsize=(6,4))
sns.histplot(df['Sales'], bins=20, kde=True)
plt.title("Sales Distribution")
plt.show()

# Region-wise sales
plt.figure(figsize=(6,4))
sns.barplot(x="Region", y="Sales", data=df, estimator=sum)
plt.title("Total Sales by Region")
plt.show()

# Category-wise profit
plt.figure(figsize=(6,4))
sns.barplot(x="Category", y="Profit", data=df, estimator=sum)
plt.title("Total Profit by Category")
plt.show()

# Correlation heatmap
corr = df.corr(numeric_only=True)
plt.figure(figsize=(6,4))
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()
